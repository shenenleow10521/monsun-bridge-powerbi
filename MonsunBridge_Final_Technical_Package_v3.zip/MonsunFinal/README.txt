MONSUN BRIDGE — COMPETITION TECHNICAL BUILD v3.0

Open MonsunFinal.pbip in Power BI Desktop. All tables are embedded; no local path, API, credentials or Python runtime is needed.

Evidence policy
OBSERVED = directly published Malaysian official value or MASCO task text.
DERIVED = formula applied to official observations.
MODELLED = analytical planning output, not an administrative record.

Method summary
P1 uses eight DOSM national quarters and the verified METMalaysia 2024/25 NEMI window. TAI uses the annual Q2/Q3 baseline. No time-series forecast is claimed because the integrated series is too short.
P2 uses official district employment and income. Tourism shares, dependency weights, WME and priority are modelled planning assumptions.
P3 uses 78 MASCO-backed task records. TF-IDF plus TruncatedSVD creates latent semantic vectors; transition rankings also include geography, seasonal fit, capacity index and training-gap penalties. No vacancy or placement guarantee is claimed.
P4 applies user-selected participation, training, support and cost assumptions to the P2 planning cohort. It reports worker-month coverage, not avoided income loss.

Included files
MonsunFinal.pbip + Report + SemanticModel = editable Power BI Project.
MonsunBridge_Data.xlsx = official inputs, transparent formulas, model outputs and source register.
Data/ = CSV audit trail and manifests.
BUILD_CHECKS.json + STATIC_VALIDATION.json = machine-readable build checks.

Software
Power BI Desktop with PBIP/PBIR support. No plug-ins, credentials, external API or Python runtime are required to open the embedded model.

Before submission
1. Open and Refresh. 2. Test all slicers and What-if parameters. 3. Save As TeamName_Datathon2026_Dashboard.pbix. 4. Export all four pages to TeamName_Datathon2026_Dashboard.pdf. 5. Test the PBIX/PDF on three Windows computers. 6. Put PBIX, PDF, this README and MonsunBridge_Data.xlsx into the official Dashboard ZIP.
